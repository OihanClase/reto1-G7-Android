package com.example.reto1grupo7.LoginRegistro;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.reto1grupo7.R;
import com.example.reto1grupo7.CLases.TipoUsuario;
import com.example.reto1grupo7.CLases.Usuario;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

public class Registro extends AppCompatActivity {

    // Declaración de variables globales
    private Button btnRegistrar;
    private EditText entradaNombre;
    private EditText entradaContraseña;
    private EditText entradaEmail;
    private RadioButton cliente;
    private RadioButton entrenador;
    private EditText entradaFechaNacimiento;
    private Calendar calendario; // Para gestionar la fecha seleccionada en el DatePickerDialog
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registro);

        // Inicialización de la base de datos Firestore
        firestore = FirebaseFirestore.getInstance();


        btnRegistrar = findViewById(R.id.btnRegistro);
        entradaNombre = findViewById(R.id.editTextUsuarioR);
        entradaContraseña = findViewById(R.id.editTextPasswordR);
        entradaEmail = findViewById(R.id.editTextEmailR);
        cliente = findViewById(R.id.radioButtonCliente);
        entrenador = findViewById(R.id.radioButtonEntrenador);
        entradaFechaNacimiento = findViewById(R.id.editTextDate);

        // Deshabilitar la entrada manual en el campo de fecha
        entradaFechaNacimiento.setFocusable(false);
        entradaFechaNacimiento.setKeyListener(null);

        // Inicialización del calendario para gestionar la fecha de nacimiento
        calendario = Calendar.getInstance();

        // Configuración del DatePickerDialog para seleccionar una fecha
        final DatePickerDialog.OnDateSetListener date = (view, year, monthOfYear, dayOfMonth) -> {
            calendario.set(Calendar.YEAR, year);
            calendario.set(Calendar.MONTH, monthOfYear);
            calendario.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            actualizarFecha(); // Llama al método para actualizar el campo con la fecha seleccionada
        };

        // Configurar el campo de texto de la fecha para abrir el DatePicker al hacer clic
        entradaFechaNacimiento.setOnClickListener(v -> {
            new DatePickerDialog(Registro.this, date,
                    calendario.get(Calendar.YEAR),
                    calendario.get(Calendar.MONTH),
                    calendario.get(Calendar.DAY_OF_MONTH)).show();
        });


        btnRegistrar.setOnClickListener(view -> {
            Usuario usuario = new Usuario();
            usuario.set_nombre(entradaNombre.getText().toString());
            usuario.set_contraseña(entradaContraseña.getText().toString());
            usuario.set_email(entradaEmail.getText().toString());


            if (cliente.isChecked()) {
                usuario.setTipo(TipoUsuario.CLIENTE);
            } else if (entrenador.isChecked()) {
                usuario.setTipo(TipoUsuario.ENTRENADOR);
            }

            // Configurar la fecha de nacimiento con el valor del calendario
            usuario.set_fechaNacimiento(calendario.getTime());


            if (validarUsuario(usuario)) {
                nombreEmailExistente(usuario);
            }
        });
    }

    // Actualizar el campo de texto con la fecha seleccionada
    private void actualizarFecha() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        entradaFechaNacimiento.setText(sdf.format(calendario.getTime()));
    }

    // Método para registrar el usuario en Firebase
    private void registrarUsuario(Usuario usuario) {
        // Generar un ID único para el usuario
        String id = UUID.randomUUID().toString();


        Map<String, Object> us = new HashMap<>();
        us.put("nombre", usuario.get_nombre());
        us.put("contraseña", usuario.get_contraseña());
        us.put("email", usuario.get_email());
        us.put("tipoUsuario", usuario.getTipo());

        // Guardar la fecha de nacimiento formateada
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        us.put("fechaNacimiento", sdf.format(usuario.get_fechaNacimiento()));


        firestore.collection("Usuarios").document(id).set(us);

        // Finalizar la actividad (cerrar la pantalla de registro)
        finish();
    }


    private boolean validarUsuario(Usuario usuario) {

        Pattern emailValido = Patterns.EMAIL_ADDRESS;


        Pattern contraseñaValida = Pattern.compile("^" +
                "(?=.*[@#$%^&+=*])" + // Al menos un carácter especial
                "(?=\\S+$)" + // Sin espacios en blanco
                ".{4,}" // Mínimo 4 caracteres
        );


        if (entradaNombre.getText().toString().isEmpty() ||
                entradaContraseña.getText().toString().isEmpty() ||
                entradaEmail.getText().toString().isEmpty() ||
                entradaFechaNacimiento.getText().toString().isEmpty()) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_LONG).show();
            return false;
        } else if (!emailValido.matcher(entradaEmail.getText().toString()).matches()) {
            entradaEmail.setError("Email no válido");
            return false;
        } else if (!contraseñaValida.matcher(entradaContraseña.getText().toString()).matches()) {
            entradaContraseña.setError("Contraseña no válida");
            return false;
        } else if (usuario.get_fechaNacimiento().after(Calendar.getInstance().getTime())) {
            entradaFechaNacimiento.setError("La fecha debe ser en el pasado");
            return false;
        } else if (!cliente.isChecked() && !entrenador.isChecked()) {
            Toast.makeText(this, "Elige alguna de las dos casillas", Toast.LENGTH_LONG).show();
            return false;
        }


        return true;
    }

    // Verificación de si el nombre o el email ya están registrados en Firestore
    private void nombreEmailExistente(Usuario usuario) {

        firestore.collection("Usuarios")
                .whereEqualTo("nombre", usuario.get_nombre()).get()
                .addOnCompleteListener(taskNombre -> {
                    if (taskNombre.isSuccessful()) {
                        QuerySnapshot querySnapshotNombre = taskNombre.getResult();

                        if (querySnapshotNombre != null && !querySnapshotNombre.isEmpty()) {
                            // Si el nombre ya existe, muestra un mensaje de error
                            Toast.makeText(this, "El nombre ya existe, elige otro", Toast.LENGTH_SHORT).show();
                        } else {
                            // Si el nombre no existe, verificar el email
                            firestore.collection("Usuarios")
                                    .whereEqualTo("email", usuario.get_email()).get()
                                    .addOnCompleteListener(taskEmail -> {
                                        if (taskEmail.isSuccessful()) {
                                            QuerySnapshot querySnapshotEmail = taskEmail.getResult();

                                            if (querySnapshotEmail != null && !querySnapshotEmail.isEmpty()) {
                                                // Si el email ya existe, muestra un mensaje de error
                                                Toast.makeText(this, "El Email ya existe, elige otro", Toast.LENGTH_SHORT).show();
                                            } else {
                                                // Si ni el nombre ni el email existen, procede con el registro
                                                registrarUsuario(usuario);
                                                Toast.makeText(this, "Se ha registrado con éxito", Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });
                        }
                    } else {
                        // En caso de error al consultar Firestore, mostrar un mensaje
                        Toast.makeText(this, "Error en la consulta a Firestore", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
