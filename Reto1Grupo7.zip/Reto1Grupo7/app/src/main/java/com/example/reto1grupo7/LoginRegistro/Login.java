
package com.example.reto1grupo7.LoginRegistro;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsetsController;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.reto1grupo7.Cliente.PaginaPrincipalCliente;
import com.example.reto1grupo7.Entrenador.PaginaPrincipalEntrenador;
import com.example.reto1grupo7.R;
import com.example.reto1grupo7.CLases.Usuario;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

public class Login extends AppCompatActivity {

    //Clase Usuario
    Usuario usuario = new Usuario();

    //variables Switch Night Mode
    Switch switchNightMode;
    boolean nightMode;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    //variables normales
    EditText nombre;
    EditText contraseña;
    TextView registroEntrar;
    Button btnLogin;


    //variables Base de Datos
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);


        setContentView(R.layout.activity_login);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().getInsetsController().setSystemBarsAppearance(0, WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS);
        }

        firestore = FirebaseFirestore.getInstance();

        // Listener para los insets de sistema (para aplicar márgenes si es necesario)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(0, 0, 0, systemBars.bottom); // Ajusta solo si quieres margen en la parte inferior
            return insets;


        });

        registroEntrar = findViewById(R.id.textViewCrear);
        nombre = findViewById(R.id.editTextUsuarioL);
        contraseña = findViewById(R.id.editTextPasswordL);
        btnLogin = findViewById(R.id.btnLogin);
        switchNightMode = findViewById(R.id.switchNightMode);


        //modo oscuro sharedPreferences
        sharedPreferences = getSharedPreferences("MODE", MODE_PRIVATE);
        nightMode = sharedPreferences.getBoolean("night", false);

        if (nightMode) {
            switchNightMode.setChecked(true);
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        }


        switchNightMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (nightMode) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                    editor = sharedPreferences.edit();
                    editor.putBoolean("night", false);
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                    editor = sharedPreferences.edit();
                    editor.putBoolean("night", true);
                }
                editor.apply();
            }


        });

        registroEntrar.setOnClickListener(view -> {

            Intent intentRegistro = new Intent(this, Registro.class);

            startActivity(intentRegistro);

        });


        btnLogin.setOnClickListener(view -> {
            Intent intentPantallaPrincipalCliente = new Intent(this, PaginaPrincipalCliente.class);
            Intent intentPantallaPrincipalEntrenador = new Intent(this, PaginaPrincipalEntrenador.class);
            // Consulta a Firestore
            firestore.collection("Usuarios")
                    .whereEqualTo("nombre", nombre.getText().toString()) // Buscar por nombre
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                QuerySnapshot querySnapshot = task.getResult();
                                if (!querySnapshot.isEmpty()) {
                                    // Aquí ya tenemos el documento del usuario
                                    DocumentSnapshot document = querySnapshot.getDocuments().get(0);
                                    String contraseñaGuardada = document.getString("contraseña");
                                    String tipoUsuarioGuardado = document.getString("tipoUsuario");

                                    // Verifica la contraseña
                                    if (contraseñaGuardada.equals(contraseña.getText().toString())) {

                                        //comprobar que tipo de usuario es, entrenador o cliente
                                        if (tipoUsuarioGuardado.equals("ENTRENADOR")){
                                            startActivity(intentPantallaPrincipalEntrenador);
                                            Toast.makeText(Login.this,"login exitoso", Toast.LENGTH_SHORT).show();
                                        } else if (tipoUsuarioGuardado.equals("CLIENTE")) {
                                            intentPantallaPrincipalCliente.putExtra("nombre", nombre.getText().toString());
                                            startActivity(intentPantallaPrincipalCliente);
                                            Toast.makeText(Login.this,"login exitoso", Toast.LENGTH_SHORT).show();
                                        }else{
                                            Toast.makeText(Login.this, "ha surgido un error inesperado", Toast.LENGTH_SHORT).show();
                                        }


                                    } else {

                                        Toast.makeText(Login.this, "Contraseña incorrecta", Toast.LENGTH_SHORT).show();
                                    }
                                } else {

                                    Toast.makeText(Login.this, "Usuario no encontrado", Toast.LENGTH_SHORT).show();
                                }
                            } else {

                                Toast.makeText(Login.this, "Error en la consulta", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        });


    }
}



