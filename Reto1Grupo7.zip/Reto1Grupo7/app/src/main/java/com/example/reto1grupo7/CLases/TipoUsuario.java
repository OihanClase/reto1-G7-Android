package com.example.reto1grupo7.CLases;

public enum TipoUsuario {
    CLIENTE,ENTRENADOR;
}
