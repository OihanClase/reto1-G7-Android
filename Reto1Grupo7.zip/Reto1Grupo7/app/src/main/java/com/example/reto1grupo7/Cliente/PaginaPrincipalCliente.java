package com.example.reto1grupo7.Cliente;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.example.reto1grupo7.R;

import java.util.ArrayList;

public class PaginaPrincipalCliente extends AppCompatActivity {

    private TextView holaUsuario;
    private ImageButton btnWorkOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pagina_principal_cliente);

        ImageSlider imageSlider = findViewById(R.id.imageSlider);
        if (imageSlider == null) {
            Log.e("PagPrincipalCliente", "imageSlider is null");
        }

        try {
            ArrayList<SlideModel> slideModels = new ArrayList<>();
            slideModels.add(new SlideModel(R.mipmap.foto_gimnasio1, ScaleTypes.FIT));
            slideModels.add(new SlideModel(R.mipmap.foto_gimnasio2, ScaleTypes.FIT));
            slideModels.add(new SlideModel(R.mipmap.foto_gimnasio3, ScaleTypes.FIT));


            if (imageSlider != null) {
                imageSlider.setImageList(slideModels, ScaleTypes.FIT);
            }
        } catch (Exception e) {
            Log.e("PagPrincipalCliente", "Error setting up slider", e);
        }

        holaUsuario = findViewById(R.id.textViewHolaUsuario);
        btnWorkOut = findViewById(R.id.imageButtonWorkout);


        String valorNombre = getIntent().getExtras().getString("nombre");
        String nombre = valorNombre.toUpperCase().charAt(0) + valorNombre.substring(1, valorNombre.length());
        holaUsuario.setText("Hola, "+ nombre);

        btnWorkOut.setOnClickListener(view -> {
            Intent intentPantallaWorkOut = new Intent(this, WorkOutCliente.class);
            startActivity(intentPantallaWorkOut);
        });

    }

}