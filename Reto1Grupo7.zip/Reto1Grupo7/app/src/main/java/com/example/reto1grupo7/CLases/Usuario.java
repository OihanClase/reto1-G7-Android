package com.example.reto1grupo7.CLases;

import java.util.Date;

public class Usuario {

    private String _nombre;
    private String _email;
    private String _contraseña;
    private String _id;
    private Date _fechaNacimiento;
    private TipoUsuario _tipo;

    public Usuario() {
    }

    public Usuario(String _nombre, String _email, String _contraseña, String _id, Date _fechaNacimiento, TipoUsuario _tipo) {
        this._nombre = _nombre;
        this._email = _email;
        this._contraseña = _contraseña;
        this._id = _id;
        this._fechaNacimiento = _fechaNacimiento;
        this._tipo = _tipo;
    }

    public String get_nombre() {
        return _nombre;
    }

    public void set_nombre(String _nombre) {
        this._nombre = _nombre;
    }

    public String get_email() {
        return _email;
    }

    public void set_email(String _email) {
        this._email = _email;
    }

    public String get_contraseña() {
        return _contraseña;
    }

    public void set_contraseña(String _contraseña) {
        this._contraseña = _contraseña;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public TipoUsuario getTipo() {
        return _tipo;
    }

    public void setTipo(TipoUsuario tipo) {
        this._tipo = tipo;
    }

    public Date get_fechaNacimiento() {
        return _fechaNacimiento;
    }

    public void set_fechaNacimiento(Date _fechaNacimiento) {
        this._fechaNacimiento = _fechaNacimiento;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "_nombre='" + _nombre + '\'' +
                ", _email='" + _email + '\'' +
                ", _contraseña='" + _contraseña + '\'' +
                ", _id='" + _id + '\'' +
                ", _fechaNacimiento=" + _fechaNacimiento +
                ", _tipo=" + _tipo +
                '}';
    }
}
