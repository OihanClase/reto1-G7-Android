package com.example.reto1grupo7.Cliente;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.example.reto1grupo7.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.ArrayList;
import java.util.List;

public class WorkOutCliente extends AppCompatActivity {

    private CardView femorales;

    //variables Base de Datos
    private FirebaseFirestore firestore;
    private List<TextView> textViewTitulos; // Lista para los TextViews de los títulos
    private List<TextView> textViewSubtitulos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_out_cliente);

        // Inicializar Firestore
        firestore = FirebaseFirestore.getInstance();

        femorales = findViewById(R.id.cardViewFemorales);

        // Inicializar TextViewTitutlos
        textViewTitulos = new ArrayList<>();
        textViewTitulos.add(findViewById(R.id.textViewTitulo0));
        textViewTitulos.add(findViewById(R.id.textViewTitulo1));
        textViewTitulos.add(findViewById(R.id.textViewTitulo2));
        textViewTitulos.add(findViewById(R.id.textViewTitulo3));
        textViewTitulos.add(findViewById(R.id.textViewTitulo4));
        textViewTitulos.add(findViewById(R.id.textViewTitulo5));
        textViewTitulos.add(findViewById(R.id.textViewTitulo6));
        textViewTitulos.add(findViewById(R.id.textViewTitulo7));
        textViewTitulos.add(findViewById(R.id.textViewTitulo8));
        textViewTitulos.add(findViewById(R.id.textViewTitulo9));
        textViewTitulos.add(findViewById(R.id.textViewTitulo10));
        textViewTitulos.add(findViewById(R.id.textViewTitulo11));

        // Inicializar TextViewTitutlos
        textViewSubtitulos = new ArrayList<>();
        textViewSubtitulos.add(findViewById(R.id.textViewSubtitulo0));
        textViewSubtitulos.add(findViewById(R.id.textViewSubtitulo1));
        textViewSubtitulos.add(findViewById(R.id.textViewSubtitulo2));
        textViewSubtitulos.add(findViewById(R.id.textViewSubtitulo3));
        textViewSubtitulos.add(findViewById(R.id.textViewSubtitulo4));
        textViewSubtitulos.add(findViewById(R.id.textViewSubtitulo5));
        textViewSubtitulos.add(findViewById(R.id.textViewSubtitulo6));
        textViewSubtitulos.add(findViewById(R.id.textViewSubtitulo7));
        textViewSubtitulos.add(findViewById(R.id.textViewSubtitulo8));
        textViewSubtitulos.add(findViewById(R.id.textViewSubtitulo9));
        textViewSubtitulos.add(findViewById(R.id.textViewSubtitulo10));
        textViewSubtitulos.add(findViewById(R.id.textViewSubtitulo11));

        femorales.setOnClickListener(view -> {
            finish();
        });


        ArrayList<String> ejercicios = new ArrayList<>();
        ArrayList<String> ejerciciosSubtitulos = new ArrayList<>();

        firestore.collection("workouts")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            QuerySnapshot querySnapshot = task.getResult();
                            if (querySnapshot != null && !querySnapshot.isEmpty()) {
                                ejercicios.clear();
                                ejerciciosSubtitulos.clear();

                                // Añadir los ids de los documentos a la lista
                                for (DocumentSnapshot document : querySnapshot.getDocuments()) {
                                    ejercicios.add(document.getId());
                                    ejerciciosSubtitulos.add(document.getLong("nivel").toString());
                                }

                                // Asignar los nombres a los TextViews
                                for (int i = 0; i < textViewTitulos.size() && i < ejercicios.size(); i++) {
                                    String nombreEjercicio = ejercicios.get(i);
                                    textViewTitulos.get(i).setText(nombreEjercicio);

                                    String nivelEjercicio = ejerciciosSubtitulos.get(i);
                                    textViewSubtitulos.get(i).setText("nivel: " + nivelEjercicio);
                                }

                            } else {
                                Toast.makeText(WorkOutCliente.this, "No hay ejercicios disponibles", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(WorkOutCliente.this, "Error en la consulta", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}
